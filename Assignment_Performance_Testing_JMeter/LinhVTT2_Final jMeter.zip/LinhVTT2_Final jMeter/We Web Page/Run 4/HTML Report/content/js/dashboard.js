/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 95.46372155498126, "KoPercent": 4.536278445018734};
    var dataset = [
        {
            "label" : "KO",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "OK",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.2245359642439143, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.03332704817573301, 500, 1500, "We HTTP Request"], "isController": false}, {"data": [0.4846153846153846, 500, 1500, "We HTTP Request-2"], "isController": false}, {"data": [0.5824097436743934, 500, 1500, "We HTTP Request-0"], "isController": false}, {"data": [0.057567146933289313, 500, 1500, "We HTTP Request-1"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 254614, 11550, 4.536278445018734, 10565.648746730389, 46, 1800915, 5489.9000000000015, 157037.30000000066, 1779407.7100000002, 141.37093393520948, 5518.196888134808, 20.884196014375068], "isController": false}, "titles": ["Label", "#Samples", "KO", "Error %", "Average", "Min", "Max", "90th pct", "95th pct", "99th pct", "Throughput", "Received", "Sent"], "items": [{"data": ["We HTTP Request", 84856, 5796, 6.83039502215518, 15976.362154709072, 161, 1800915, 10600.800000000003, 60339.95, 1725318.2200000011, 47.115131021884636, 2759.1272301412796, 10.442098007187534], "isController": false}, {"data": ["We HTTP Request-2", 130, 67, 51.53846153846154, 40369.107692307705, 150, 149321, 146440.9, 147812.25, 149033.94, 0.8680323709302636, 9.980905113628776, 0.07159702097967469], "isController": false}, {"data": ["We HTTP Request-0", 84814, 0, 0.0, 1070.68664371447, 46, 74244, 1187.9000000000015, 1645.9500000000007, 3027.970000000005, 47.11436067533509, 19.60031020282495, 5.24515343455879], "isController": false}, {"data": ["We HTTP Request-1", 84814, 5687, 6.705260923904072, 14601.536326549902, 107, 1800572, 9670.400000000023, 60163.0, 1714614.5600000003, 47.093719911913745, 2738.759780601805, 5.1937118797481565], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Percentile 1
            case 8:
            // Percentile 2
            case 9:
            // Percentile 3
            case 10:
            // Throughput
            case 11:
            // Kbytes/s
            case 12:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 16, 0.13852813852813853, 0.00628402208833764], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: chungta.vn:443 failed to respond", 70, 0.6060606060606061, 0.027492596636477178], "isController": false}, {"data": ["502/Bad Gateway", 8714, 75.44588744588745, 3.4224355298608873], "isController": false}, {"data": ["504/Gateway Time-out", 1124, 9.731601731601732, 0.44145255170571923], "isController": false}, {"data": ["Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 1341, 11.61038961038961, 0.5266796012787985], "isController": false}, {"data": ["Non HTTP response code: javax.net.ssl.SSLHandshakeException/Non HTTP response message: Remote host closed connection during handshake", 246, 2.1298701298701297, 0.09661683960819123], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of chunk coded message body: closing chunk expected", 38, 0.329004329004329, 0.014924552459801897], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: chungta.vn:80 failed to respond", 1, 0.008658008658008658, 3.927513805211025E-4], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 254614, 11550, "502/Bad Gateway", 8714, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 1341, "504/Gateway Time-out", 1124, "Non HTTP response code: javax.net.ssl.SSLHandshakeException/Non HTTP response message: Remote host closed connection during handshake", 246, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: chungta.vn:443 failed to respond", 70], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["We HTTP Request", 84856, 5796, "502/Bad Gateway", 4357, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 691, "504/Gateway Time-out", 562, "Non HTTP response code: javax.net.ssl.SSLHandshakeException/Non HTTP response message: Remote host closed connection during handshake", 123, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: chungta.vn:443 failed to respond", 35], "isController": false}, {"data": ["We HTTP Request-2", 130, 67, "504/Gateway Time-out", 27, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 21, "Non HTTP response code: org.apache.http.ConnectionClosedException/Non HTTP response message: Premature end of chunk coded message body: closing chunk expected", 19, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": ["We HTTP Request-1", 84814, 5687, "502/Bad Gateway", 4357, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 629, "504/Gateway Time-out", 535, "Non HTTP response code: javax.net.ssl.SSLHandshakeException/Non HTTP response message: Remote host closed connection during handshake", 123, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: chungta.vn:443 failed to respond", 35], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
