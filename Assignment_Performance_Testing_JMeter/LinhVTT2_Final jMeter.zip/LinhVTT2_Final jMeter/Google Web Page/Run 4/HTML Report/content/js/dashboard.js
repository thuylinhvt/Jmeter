/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 35.509293464876066, "KoPercent": 64.49070653512393};
    var dataset = [
        {
            "label" : "KO",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "OK",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.11704719409313263, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.0, 500, 1500, "Google HTTP Request-2"], "isController": false}, {"data": [0.014084353146853147, 500, 1500, "Google HTTP Request-1"], "isController": false}, {"data": [0.3344041375291375, 500, 1500, "Google HTTP Request-0"], "isController": false}, {"data": [0.004565947793125233, 500, 1500, "Google HTTP Request"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 414162, 267096, 64.49070653512393, 5815.662484728137, 26, 1757598, 10212.700000000048, 26038.750000000004, 83833.72000000053, 230.08399225131342, 621.1461943771468, 48.411648244462505], "isController": false}, "titles": ["Label", "#Samples", "KO", "Error %", "Average", "Min", "Max", "90th pct", "95th pct", "99th pct", "Throughput", "Received", "Sent"], "items": [{"data": ["Google HTTP Request-2", 310, 310, 100.0, 3394.9000000000015, 54, 89686, 8381.8, 13277.35, 41723.49, 3.4497340366339495, 10.35016930473949, 0.7387629782332911], "isController": false}, {"data": ["Google HTTP Request-1", 137280, 132232, 96.32284382284382, 3811.6735868298683, 26, 1753773, 6115.9000000000015, 8442.0, 79804.99, 76.27416695975104, 254.62667728732907, 15.680491567781942], "isController": false}, {"data": ["Google HTTP Request-0", 137280, 0, 0.0, 4251.533551864799, 90, 119153, 8634.0, 13431.0, 42463.840000000026, 76.26759882620787, 54.17054489693763, 8.490728775573924], "isController": false}, {"data": ["Google HTTP Request", 139292, 134554, 96.59851247738564, 9337.628227033947, 235, 1757598, 16054.700000000004, 43377.30000000001, 89525.0, 77.38242390337585, 311.8660332636453, 24.205824122231252], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Percentile 1
            case 8:
            // Percentile 2
            case 9:
            // Percentile 3
            case 10:
            // Throughput
            case 11:
            // Kbytes/s
            case 12:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Non HTTP response code: java.net.NoRouteToHostException/Non HTTP response message: No route to host (Host unreachable)", 3397, 1.2718273579536945, 0.8202104490513374], "isController": false}, {"data": ["Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 25, 0.00935993051187588, 0.006036285318305397], "isController": false}, {"data": ["503/Service Unavailable", 22724, 8.5078024380747, 5.486741902926874], "isController": false}, {"data": ["Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 954, 0.3571749483331836, 0.23034464774653396], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to www.google.com:80 [www.google.com\/216.58.199.4] failed: Operation timed out (Connection timed out)", 30, 0.011231916614251056, 0.007243542381966477], "isController": false}, {"data": ["429/Too Many Requests", 239966, 89.84260340851229, 57.94012970769892], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 414162, 267096, "429/Too Many Requests", 239966, "503/Service Unavailable", 22724, "Non HTTP response code: java.net.NoRouteToHostException/Non HTTP response message: No route to host (Host unreachable)", 3397, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 954, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to www.google.com:80 [www.google.com\/216.58.199.4] failed: Operation timed out (Connection timed out)", 30], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["Google HTTP Request-2", 310, 310, "429/Too Many Requests", 309, "Non HTTP response code: java.net.NoRouteToHostException/Non HTTP response message: No route to host (Host unreachable)", 1, null, null, null, null, null, null], "isController": false}, {"data": ["Google HTTP Request-1", 137280, 132232, "429/Too Many Requests", 119674, "503/Service Unavailable", 11362, "Non HTTP response code: java.net.NoRouteToHostException/Non HTTP response message: No route to host (Host unreachable)", 930, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 244, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to www.google.com:80 [www.google.com\/216.58.199.4] failed: Operation timed out (Connection timed out)", 15], "isController": false}, {"data": [], "isController": false}, {"data": ["Google HTTP Request", 139292, 134554, "429/Too Many Requests", 119983, "503/Service Unavailable", 11362, "Non HTTP response code: java.net.NoRouteToHostException/Non HTTP response message: No route to host (Host unreachable)", 2466, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 710, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 18], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
