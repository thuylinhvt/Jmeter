/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 99.44950944824758, "KoPercent": 0.5504905517524212};
    var dataset = [
        {
            "label" : "KO",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "OK",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.7160162781160289, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.8170171478357293, 500, 1500, "Tiki HTTP Request-1"], "isController": false}, {"data": [0.96086508753862, 500, 1500, "Tiki HTTP Request-2"], "isController": false}, {"data": [0.852193034589326, 500, 1500, "Tiki HTTP Request-3"], "isController": false}, {"data": [0.6050453447388222, 500, 1500, "Tiki HTTP Request-0"], "isController": false}, {"data": [0.35309388197915453, 500, 1500, "Tiki HTTP Request"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 126796, 698, 0.5504905517524212, 4090.620043219028, 0, 1837523, 2430.0, 8162.950000000001, 41229.890000000814, 63.37154238105591, 124.03608163513609, 15.020649777155537], "isController": false}, "titles": ["Label", "#Samples", "KO", "Error %", "Average", "Min", "Max", "90th pct", "95th pct", "99th pct", "Throughput", "Received", "Sent"], "items": [{"data": ["Tiki HTTP Request-1", 25251, 5, 0.01980119599223793, 680.8078491940913, 8, 1574304, 1196.0, 1643.800000000003, 3591.970000000005, 12.62085552516674, 8.830052298566628, 1.7621337613383274], "isController": false}, {"data": ["Tiki HTTP Request-2", 25246, 7, 0.027727164699358313, 197.57771528163013, 0, 101443, 183.90000000000146, 328.0, 1291.9700000000048, 13.106008850163942, 9.630722644528971, 2.2263801142947175], "isController": false}, {"data": ["Tiki HTTP Request-3", 25239, 58, 0.2298030825310036, 5037.929632711272, 20, 1834508, 2515.5000000000073, 10177.0, 11349.920000000013, 12.615299105397902, 41.89049772988095, 2.23701972087045], "isController": false}, {"data": ["Tiki HTTP Request-0", 25251, 0, 0.0, 1361.384301611806, 3, 81271, 2210.0, 2492.0, 4581.960000000006, 13.108597705541161, 1.7665883626608208, 1.420951509096747], "isController": false}, {"data": ["Tiki HTTP Request", 25809, 628, 2.4332597156030844, 12978.670696268777, 0, 1837523, 7088.9000000000015, 11453.750000000004, 84706.56000000071, 12.899114619646298, 62.34681249094128, 7.5103248885777685], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Percentile 1
            case 8:
            // Percentile 2
            case 9:
            // Percentile 3
            case 10:
            // Throughput
            case 11:
            // Kbytes/s
            case 12:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 2, 0.28653295128939826, 0.0015773368245055048], "isController": false}, {"data": ["Non HTTP response code: java.net.SocketException/Non HTTP response message: Network is unreachable (connect failed)", 288, 41.260744985673355, 0.2271365027287927], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to 10.16.34.126:80 [\/10.16.34.126] failed: Operation timed out (Connection timed out)", 6, 0.8595988538681948, 0.004732010473516515], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to tiki.vn:80 [tiki.vn\/203.162.81.187] failed: Operation timed out (Connection timed out)", 112, 16.045845272206304, 0.08833086217230827], "isController": false}, {"data": ["Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 194, 27.793696275071632, 0.153001671977034], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: tiki.vn:80 failed to respond", 52, 7.4498567335243555, 0.04101075743714313], "isController": false}, {"data": ["Non HTTP response code: java.net.UnknownHostException/Non HTTP response message: tiki.vn", 14, 2.005730659025788, 0.011041357771538534], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: 10.16.34.126:80 failed to respond", 24, 3.438395415472779, 0.01892804189406606], "isController": false}, {"data": ["Non HTTP response code: java.net.SocketException/Non HTTP response message: Operation timed out (Read failed)", 3, 0.4297994269340974, 0.0023660052367582575], "isController": false}, {"data": ["Non HTTP response code: java.net.UnknownHostException/Non HTTP response message: tiki.vn: nodename nor servname provided, or not known", 1, 0.14326647564469913, 7.886684122527524E-4], "isController": false}, {"data": ["Non HTTP response code: java.net.NoRouteToHostException/Non HTTP response message: Can't assign requested address (Address not available)", 2, 0.28653295128939826, 0.0015773368245055048], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 126796, 698, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Network is unreachable (connect failed)", 288, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 194, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to tiki.vn:80 [tiki.vn\/203.162.81.187] failed: Operation timed out (Connection timed out)", 112, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: tiki.vn:80 failed to respond", 52, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: 10.16.34.126:80 failed to respond", 24], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["Tiki HTTP Request-1", 25251, 5, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to 10.16.34.126:80 [\/10.16.34.126] failed: Operation timed out (Connection timed out)", 3, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 1, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Operation timed out (Read failed)", 1, null, null, null, null], "isController": false}, {"data": ["Tiki HTTP Request-2", 25246, 7, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: 10.16.34.126:80 failed to respond", 6, "Non HTTP response code: java.net.NoRouteToHostException/Non HTTP response message: Can't assign requested address (Address not available)", 1, null, null, null, null, null, null], "isController": false}, {"data": ["Tiki HTTP Request-3", 25239, 58, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 52, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: 10.16.34.126:80 failed to respond", 6, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": ["Tiki HTTP Request", 25809, 628, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Network is unreachable (connect failed)", 288, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Socket closed", 141, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to tiki.vn:80 [tiki.vn\/203.162.81.187] failed: Operation timed out (Connection timed out)", 112, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: tiki.vn:80 failed to respond", 52, "Non HTTP response code: java.net.UnknownHostException/Non HTTP response message: tiki.vn", 14], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
